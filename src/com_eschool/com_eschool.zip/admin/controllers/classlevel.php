<?php
defined('_JEXEC') or die;
jimport('joomla.application.component.controllerform');

/**
 * Classlevel Subcontroller.
 *
 * @package     E-School Management
 * @subpackage  com_eschool
 * @since       1.0
 */
class EschoolControllerClasslevel extends JControllerForm
{
}