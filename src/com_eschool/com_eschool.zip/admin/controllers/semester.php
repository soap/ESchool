<?php
defined('_JEXEC') or die;
jimport('joomla.application.component.controllerform');

/**
 * Semester Subcontroller.
 *
 * @package     E-School Management
 * @subpackage  com_eschool
 * @since       1.0
 */
class EschoolControllerSemester extends JControllerForm
{
}